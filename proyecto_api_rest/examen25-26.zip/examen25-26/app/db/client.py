from pymongo import MongoClient

db_client = MongoClient()